# Sample project for OOD of a Table reservation system

Execute the main with 
```
mvn clean compile exec:java
```

Run the tests with
```
mvn test
```
